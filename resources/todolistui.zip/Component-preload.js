//@ui5-bundle todolistui/Component-preload.js
sap.ui.require.preload({
	"todolistui/Component.js":function(){
sap.ui.define(["sap/ui/core/UIComponent","sap/ui/Device","todolistui/model/models"],function(e,t,i){"use strict";return e.extend("todolistui.Component",{metadata:{manifest:"json"},init:function(){e.prototype.init.apply(this,arguments);this.getRouter().initialize();this.setModel(i.createDeviceModel(),"device")}})});
},
	"todolistui/controller/App.controller.js":function(){
sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("todolistui.controller.App",{onInit:function(){}})});
},
	"todolistui/controller/Home.controller.js":function(){
sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("todolistui.controller.Home",{onInit:function(){}})});
},
	"todolistui/i18n/i18n.properties":'# This is the resource bundle for todolistui\n\n#Texts for manifest.json\n\n#XTIT: Application name\nappTitle=App Title\n\n#YDES: Application description\nappDescription=An SAP Fiori application.\n#XTIT: Main view title\ntitle=App Title',
	"todolistui/manifest.json":'{"_version":"1.59.0","sap.app":{"id":"todolistui","type":"application","i18n":"i18n/i18n.properties","applicationVersion":{"version":"0.0.1"},"title":"{{appTitle}}","description":"{{appDescription}}","resources":"resources.json","sourceTemplate":{"id":"@sap/generator-fiori:basic","version":"1.12.2","toolsId":"2549eb7c-7dab-47c8-92e0-c737abeb67da"},"dataSources":{"cap":{"uri":"v2/odata/v4/catalog","type":"OData","settings":{"odataVersion":"2.0"}}}},"sap.ui":{"technology":"UI5","icons":{"icon":"","favIcon":"","phone":"","phone@2":"","tablet":"","tablet@2":""},"deviceTypes":{"desktop":true,"tablet":true,"phone":true}},"sap.ui5":{"flexEnabled":false,"dependencies":{"minUI5Version":"1.120.5","libs":{"sap.m":{},"sap.ui.core":{},"sap.f":{},"sap.suite.ui.generic.template":{},"sap.ui.comp":{},"sap.ui.generic.app":{},"sap.ui.table":{},"sap.ushell":{}}},"contentDensities":{"compact":true,"cozy":true},"models":{"i18n":{"type":"sap.ui.model.resource.ResourceModel","settings":{"bundleName":"todolistui.i18n.i18n"}},"":{"dataSource":"cap","settings":{"operationMode":"Server","defaultBindingMode":"TwoWay"}}},"resources":{"css":[{"uri":"css/style.css"}]},"routing":{"config":{"routerClass":"sap.m.routing.Router","viewType":"XML","async":true,"viewPath":"todolistui.view","controlAggregation":"pages","controlId":"app","clearControlAggregation":false},"routes":[{"name":"RouteHome","pattern":":?query:","target":["TargetHome"]}],"targets":{"TargetHome":{"viewType":"XML","transition":"slide","clearControlAggregation":false,"viewId":"Home","viewName":"Home"}}},"rootView":{"viewName":"todolistui.view.App","type":"XML","async":true,"id":"App"}}}',
	"todolistui/model/models.js":function(){
sap.ui.define(["sap/ui/model/json/JSONModel","sap/ui/Device"],function(e,n){"use strict";return{createDeviceModel:function(){var i=new e(n);i.setDefaultBindingMode("OneWay");return i}}});
},
	"todolistui/view/App.view.xml":'<mvc:View controllerName="todolistui.controller.App"\n    xmlns:html="http://www.w3.org/1999/xhtml"\n    xmlns:mvc="sap.ui.core.mvc" displayBlock="true"\n    xmlns="sap.m"><App id="app"></App></mvc:View>\n',
	"todolistui/view/Home.view.xml":'<mvc:View controllerName="todolistui.controller.Home"\n    xmlns:mvc="sap.ui.core.mvc" displayBlock="true"\n    xmlns="sap.m"><Page id="page" title="{i18n>title}"><Table mode="SingleSelect" items="{path: \'/Books\'}"><columns><Column ><Text text="Title"></Text></Column><Column ><Text text="Stock"></Text></Column></columns><items><ColumnListItem ><cells><Text text="{title}"></Text><Text text="{stock}"></Text></cells></ColumnListItem></items></Table></Page></mvc:View>\n'
});
//# sourceMappingURL=Component-preload.js.map
