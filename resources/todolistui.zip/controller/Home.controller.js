sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("todolistui.controller.Home",{onInit:function(){}})});
//# sourceMappingURL=Home.controller.js.map